﻿# Original source paths
- mcr2 / tracing files from BaseRoot and earlier result folders

