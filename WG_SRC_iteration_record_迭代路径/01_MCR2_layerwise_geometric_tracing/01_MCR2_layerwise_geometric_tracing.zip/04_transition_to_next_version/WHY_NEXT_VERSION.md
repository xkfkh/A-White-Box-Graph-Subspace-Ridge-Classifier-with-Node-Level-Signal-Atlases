﻿# Why move to the next stage?

Geometric tracing diagnoses a trained model, but it does not yet create a new white-box graph classifier.
The next step was to rewrite GNN layers as white-box optimization-like updates.

